# bounds_checking_function

#### Description

- following the standard of C11 Annex K (bound-checking interfaces), functions of the common memory/string operation classes, such as memcpy_s, strcpy_s, are selected and implemented.

- other standard functions in C11 Annex K will be analyzed in the future and implemented in this organization if necessary.

- handles the release, update, and maintenance of bounds_checking_function.
